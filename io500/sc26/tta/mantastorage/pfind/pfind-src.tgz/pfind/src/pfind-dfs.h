#include <sys/types.h>
#include <sys/stat.h>
#include <daos_fs.h>

void pfind_init_daos(MPI_Comm comm);
void pfind_fini_daos(MPI_Comm comm);
DIR* pfind_dfs_opendir(const char* dir, int *nr);
int pfind_dfs_closedir(DIR* _dirp);
struct dirent* pfind_dfs_readdir(DIR* _dirp);
int pfind_dfs_lstat(const char* path, struct stat* buf);
int pfind_dfs_lookup(const char* path, mode_t* mode, dfs_obj_t** obj);
int pfind_dfs_fstat(dfs_obj_t* obj, struct stat* buf);
void pfind_dfs_release(dfs_obj_t* obj);
